const sqlite3 = require('sqlite3').verbose();
const Discord = require('discord.js');
/*
Code By Ghlais
*/
module.exports = {
  name: 'warns',
  description: 'عرض عدد التحذيرات لشخص معين',
  execute(message, args) {
    /*
Code By Ghlais
*/
    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!member) {
      return message.channel.send('يرجى ذكر عضو صحيح لعرض تحذيراته.');
    }

    /*
Code By Ghlais
*/
    const db = new sqlite3.Database(`warnings_${message.guild.id}.db`);

    // الحصول على جميع التحذيرات للعضو
    db.all('SELECT * FROM warnings WHERE user_id = ?', [member.id], function(err, rows) {
      if (err) {
        console.error(err);
        return message.channel.send('حدث خطأ أثناء تنفيذ الأمر.');
      }

      if (rows.length === 0) {
        return message.channel.send('لم يتم العثور على تحذيرات لهذا العضو.');
      }

      /*
Code By Ghlais
*/
      const embed = new Discord.MessageEmbed()
        .setColor('BLUE')
        .setTitle(`عدد التحذيرات لـ${member.displayName}`)
        .setDescription(`عدد التحذيرات: ${rows.length}`);
/*
Code By Ghlais
*/
      rows.forEach((row, index) => {
        embed.addField(`التحذير ال${index + 1}`, [
          `المشرف: ${message.guild.members.cache.get(row.moderator_id)}`,
          `سبب التحذير: ${row.reason}`,
          `رقم التحذير: ${row.id}`
        ].join('\n'));
        embed.addField('\u200B', '\u200B');
      });
/*
Code By Ghlais
*/
      message.channel.send(embed);
    });
  },
};

/*
Code By Ghlais
*/