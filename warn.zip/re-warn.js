const sqlite3 = require('sqlite3').verbose();
const Discord = require('discord.js');
/*
Code By Ghlais
*/
module.exports = {
  name: 're-warn',
  description: 'سحب تحذير من عضو',
  execute(message, args) {
    /*
Code By Ghlais
*/
    if (!message.member.hasPermission('ADMINISTRATOR')) {
      return message.channel.send('ليس لديك الصلاحية لسحب التحذيرات.');
    }

    /*
Code By Ghlais
*/
    const member = message.mentions.members.first();
    if (!member) {
      return message.channel.send('يرجى ذكر عضو صحيح لسحب تحذيراته.');
    }

    /*
Code By Ghlais
*/
    const warnName = args.slice(1).join(' ');
    if (!warnName) {
      return message.channel.send('يرجى تقديم اسم تحذير صحيح لسحبه.');
    }

    /*
Code By Ghlais
*/
    const db = new sqlite3.Database(`warnings_${message.guild.id}.db`);

    /*
Code By Ghlais
*/
    db.get('SELECT * FROM warnings WHERE user_id = ? AND reason = ?', [member.id, warnName], function(err, row) {
      if (err) {
        console.error(err);
        return message.channel.send('حدث خطأ أثناء تنفيذ الأمر.');
      }
/*
Code By Ghlais
*/
      if (!row) {
        return message.channel.send('لم يتم العثور على تحذير بهذا الاسم لهذا العضو.');
      }

      /*
Code By Ghlais
*/
      db.run('DELETE FROM warnings WHERE id = ?', [row.id], function(err) {
        if (err) {
          console.error(err);
          return message.channel.send('حدث خطأ أثناء تنفيذ الأمر.');
        }

        /*
Code By Ghlais
*/
        const embed = new Discord.MessageEmbed()
          .setColor('GREEN')
          .setTitle('تم سحب تحذير')
          .addField('المسؤول', message.author)
          .addField('الشخص', member)
          .addField('التحذير المسحوب', row.reason);

        message.channel.send(embed);
      });
    });
  },
};

/*
Code By Ghlais
*/