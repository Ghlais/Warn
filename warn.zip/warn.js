/*
Code By Ghlais
*/

const sqlite3 = require('sqlite3').verbose();
const Discord = require('discord.js');
/*
Code By Ghlais
*/
module.exports = {
  name: 'warn',
  description: 'تحذير الأعضاء',
  execute(message, args) {
    /*
Code By Ghlais
*/
    if (!message.member.hasPermission('ADMINISTRATOR')) {
      return message.channel.send('ليس لديك الصلاحية لتحذير الأعضاء.');
    }

    /*
Code By Ghlais
*/
    const member = message.mentions.members.first();
    if (!member) {
      return message.channel.send('يرجى ذكر عضو صحيح لتحذيره.');
    }

    /*
Code By Ghlais
*/
    const reason = args.slice(1).join(' ');
    if (!reason) {
      return message.channel.send('يرجى تقديم سبب للتحذير.');
    }

    /*
Code By Ghlais
*/
    const db = new sqlite3.Database(`warnings_${message.guild.id}.db`);

    /*
Code By Ghlais
*/
    db.run(`CREATE TABLE IF NOT EXISTS warnings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT,
      moderator_id TEXT,
      reason TEXT
    )`);

    /*
Code By Ghlais
*/
    db.run('INSERT INTO warnings (user_id, moderator_id, reason) VALUES (?, ?, ?)', [member.id, message.author.id, reason], function(err) {
      if (err) {
        console.error(err);
        return message.channel.send('حدث خطأ أثناء تنفيذ الأمر.');
      }

      /*
Code By Ghlais
*/
      const embed = new Discord.MessageEmbed()
        .setColor('RED')
        .setTitle('تم اعطاء تحذير')
        .addField('المسؤول', message.author)
        .addField('الشخص الذي تم اعطائه تحذير', member)
        .addField('سبب التحذير', reason);

      message.channel.send(embed);
    });
  },
};

/*
Code By Ghlais
*/